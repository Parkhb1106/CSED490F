import torch
from torch.nn.parallel import DistributedDataParallel as DDP

def model_to_DDP(model):
    ''' Problem 4: model to DDP
    (./handler/DDP/model.py)
    Implement model_to_DDP function.
    model_to_DDP function is used to transfer model to DDP, SIMILAR with DP.
    Be careful for set devices. Set profer device id is important part in DDP.
    '''
    # is non CUDA env
    if not torch.cuda.is_available():
        return model

    # Use GPU that this process is bound to.:
    local_rank = torch.cuda.current_device()
    model = model.to(local_rank)

    # Wrap model with DDP.
    ddp_model = DDP(
        model,
        device_ids=[local_rank],
        output_device=local_rank
    )
    return ddp_model